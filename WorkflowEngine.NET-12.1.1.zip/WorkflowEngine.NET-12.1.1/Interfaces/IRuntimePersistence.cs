﻿namespace OptimaJet.Workflow.Core.Persistence
{
    /// <summary>
    /// Provides save and load of workflow runtime parameters. as timers etc
    /// </summary>
    [System.Obsolete("Interface is not used")]
    public interface IRuntimePersistence
    {

    }
}
