﻿namespace AbpAngularSample.WorkflowSchemes.Dto
{
    //WorkflowEngineSampleCode
    public class WorkflowSchemeDto
    {
        public string Code { get; set; }
    }
}