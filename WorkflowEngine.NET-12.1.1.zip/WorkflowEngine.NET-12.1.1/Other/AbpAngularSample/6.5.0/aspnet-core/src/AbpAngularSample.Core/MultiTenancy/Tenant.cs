﻿using Abp.MultiTenancy;
using AbpAngularSample.Authorization.Users;

namespace AbpAngularSample.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
