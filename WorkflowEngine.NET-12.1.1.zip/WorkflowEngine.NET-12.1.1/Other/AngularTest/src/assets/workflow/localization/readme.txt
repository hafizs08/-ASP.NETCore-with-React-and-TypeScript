/*
 * WorkflowEngine.NET
 * https://workflowengine.io
 * Email: support@optimajet.com
 */

This folder contains localization files for the Workflow Engine Designer.
These files have been created by Google Translate.

Include your language file after workflowdesigner.min.js, like this for French:

<script src="/Scripts/workflowdesigner.min.js" type="text/javascript"></script>
<script src="/Scripts/workflowdesigner.localization_fr.js" type="text/javascript"></script>



