This sample uses https://workflowengine.io/demo/Designer/API as a backend.

**Make sure that you enable CORS in your browser (!!!)** 

Instruction: [for chrome](https://chrome.google.com/webstore/detail/allow-control-allow-origi/nlfbmbojpeacfghkpbjhddihlkkiljbi?hl=en), [for others](https://www.google.com/search?ei=M28OXO7BDauk_QaC06DABg&q=browser+how+to+enable+CORS&oq=browser+how+to+enable+CORS).


If you set up your [own backend with DesignerAPI](https://workflowengine.io/documentation/main-terms/designer/#backend), replace apiurl in app.component.ts file.

