module.exports = {
  en: require('./en_default.json'),
  de: require('./de.json'),
  es: require('./es.json'),
  fr: require('./fr.json'),
  it: require('./it.json'),
  pt: require('./pt.json'),
  ru: require('./ru.json'),
  tr: require('./tr.json'),
  ar: require('./ar.json')
};
